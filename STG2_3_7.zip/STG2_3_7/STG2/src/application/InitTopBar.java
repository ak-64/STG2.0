package application;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class InitTopBar {
	static Label fps;
	static Label time;
	static Label score;
	static ImageView playimgView[];
	static ImageView playimgOne;
	static ProgressBar pb1;
	static ProgressBar pb2;
	InitTopBar(){

		fps = new Label();
		time = new Label();
		score = new Label();

		HBox hbox = new HBox();
		VBox vbox = new VBox();
		HBox hbox1 = new HBox();
		HBox hbox1_1 = new HBox();
		HBox hbox2 = new HBox();
		HBox hbox3_1 = new HBox();
		HBox hbox3_2 = new HBox();

		fps.setFont( Font.font( "IMPACT", 25 ) );
		fps.setTextFill( Color.web( "#0076a3" ) );
		time.setFont( Font.font( "IMPACT", 25 ) );
		time.setTextFill( Color.web( "#0076a3" ) );
		score.setFont( Font.font( "IMPACT", 25 ) );
		score.setTextFill( Color.web( "#0076a3" ) );

		pb1 = new ProgressBar( 1 );
		pb2 = new ProgressBar( 1 );

		pb2.setStyle("-fx-accent: red;");
		pb2.setVisible( false );

		hbox.setAlignment( Pos.CENTER );
		hbox1.setAlignment( Pos.CENTER_LEFT );
		hbox1_1.setAlignment( Pos.CENTER_LEFT );
	    hbox2.setAlignment( Pos.CENTER_RIGHT );
	    hbox3_1.setAlignment( Pos.CENTER );
	    hbox3_2.setAlignment( Pos.CENTER );
	    vbox.setAlignment( Pos.CENTER );

	    hbox.setPrefSize( Cons.FRAME_W , Cons.TOP_BAR );
	    hbox1.setPrefSize( Cons.FRAME_W / 4, Cons.TOP_BAR );
	    hbox1_1.setPrefSize( Cons.FRAME_W / 4, Cons.TOP_BAR );
	    hbox2.setPrefSize( Cons.FRAME_W / 4, Cons.TOP_BAR );
	    hbox3_1.setPrefSize( Cons.FRAME_W / 4, Cons.TOP_BAR / 2 );
	    hbox3_2.setPrefSize( Cons.FRAME_W / 4, Cons.TOP_BAR / 2 );
	    vbox.setPrefSize( Cons.FRAME_W / 4, Cons.TOP_BAR );

		hbox1.getChildren().add( fps );
		hbox1_1.getChildren().add( time );
		hbox2.getChildren().add( score );
		hbox3_1.getChildren().add( pb1 );
		hbox3_2.getChildren().add( pb2 );

		vbox.getChildren().addAll( hbox3_2, hbox3_1 );
		hbox.getChildren().addAll( hbox1, hbox1_1, hbox2, vbox );
		Main.root.getChildren().add( hbox );
	}


//�@TOP�o�[�@�e�L�X�g����
	public static void fpsText( String s ){
		fps.setText( " FPS : " + s );
	}
	public static void timeText( String s ){
		time.setText( " TIME : " + s );
	}
	public static void scoreText( String s ){
		score.setText( s );
	}
// TOP�o�[�@HP�Q�[�W����
	public static void getHP1(){
		double HP = ( double )Cons.HP / Cons.HP_MAX ;
		pb1.setProgress( HP );
	}

	public static void getHP2(){
		double HP = ( double )Cons.HP_BOSS / Cons.HP_MAX_BOSS ;
		pb2.setProgress( HP );
	}
}