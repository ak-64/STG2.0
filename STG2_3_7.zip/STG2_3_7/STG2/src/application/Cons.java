package application;

public class Cons{
	// private�R���X�g���N�^�ŃC���X�^���X������}�~
	private Cons(){}

	// �萔
	public static final double	FRAME_W		= 540.0;
	public static final double	FRAME_H		= 580.0;
	public static final double	GAME_H			= 540.0;
	public static final double	TOP_BAR		= 40.0;
	public static final double	SPEED_P		= 300.0;
	public static final double	SPEED_B		= 1000;
	public static final double	SPEED_A		= 100.0;
	public static final double	ALIEN_MOVE_W	= 200.0;
	public static final double	DEAD_X			= -120.0;
	public static final double	DEAD_Y			= -120.0;
	public static final int		HP_MAX			= 10;
	public static final int		HP_MAX_BOSS	= 30;
	public static final int    	UNDEAD_TIME	= 3;
	public static final int    	A_NUM			= 40;
	public static final int    	As_NUM			= 8;
	public static final int    	B_NUM			= 20;
	public static final int    	B_A_NUM		= As_NUM;
	public static final int    	B_INTERVAL		= 100;
	public static final int    	BA_INTERVAL	= 10;
	public static final int    	START_SCENE	= 0;
	public static final int    	GAME_SCENE		= 1;
	public static final int    	FIN_SCENE		= 2;
	public static final int    	RESTART_SCENE	= 3;
	public static final int    	REGAME_SCENE	= 4;

	public static final String PLAYER_IMAGE		= "image/player.gif";
	public static final String PLAYER_CORE_IMAGE	= "image/playercore.gif";
	public static final String BEAM_IMAGE			= "image/RED_BEAM1.gif";
	public static final String ALIEN_PINK			= "image/alienPINK.gif";
	public static final String ALIEN_GREEN			= "image/alienGREEN.gif";
	public static final String ALIEN_BULE			= "image/alienBLUE.gif";
	public static final String ALIEN_PURPLE		= "image/alienPURPLE.gif";
	public static final String ALIEN_RED			= "image/alienRED.gif";
	public static final String ALIEN_YELLOW		= "image/alienYELLOW.gif";
	public static final String BEAM_BIG_BLUE		= "image/B_big.gif";
	public static final String BEAM_BIG_GREEN		= "image/G_big.gif";
	public static final String BEAM_BIG_PINK		= "image/P_big.gif";
	public static final String BEAM_BIG_RED		= "image/R_big.gif";
	public static final String BEAM_BIG_YELLOW	= "image/Y_big.gif";
	public static final String BEAM_RAG_BLUE		= "image/B_rag.gif";
	public static final String BEAM_RAG_GREEN		= "image/G_rag.gif";
	public static final String BEAM_RAG_PINK		= "image/P_rag.gif";
	public static final String BEAM_RAG_RED		= "image/R_rag.gif";
	public static final String BEAM_RAG_YELLOW	= "image/Y_rag.gif";
	public static final String BEAM_BALL_BLUE		= "image/B_ball.gif";
	public static final String BEAM_BALL_GREEN	= "image/G_ball.gif";
	public static final String BEAM_BALL_PINK		= "image/P_ball.gif";
	public static final String BEAM_BALL_RED		= "image/R_ball.gif";
	public static final String BEAM_BALL_YELLOW	= "image/Y_ball.gif";
	public static final String BEAM_LONG_COLORFUL	= "image/long_color.gif";
	public static final String BEAM_LONG_SIDE_COLORFUL	= "image/long_color_side.gif";
	public static final String BEAM_LONG_RED	= "image/R_long.gif";

	// �ϐ�
	// �t���O
	public static int			SCENE_FLAG			= 0;
	public static int    		HP					= HP_MAX;
	public static int    		HP_BOSS				= HP_MAX_BOSS;
	public static int    		DAMAGE_FLAG			= 0;
	public static int    		SCORE				= 0;
	public static int    		STAGE_CLEAR			= 0;
	public static int    		STAGE_FLAG			= 1;
	public static int    		CLEAR				= 0;

	// �t���[�����[�g
	public static long 			count			= 0;

	// �e�X�g�p
	public static String 		text			= null;
}