package application;

public class AlienFormationSprite extends AlienSprite{

	AlienFormationSprite( double x, double y ){
		super( -100, -100 );
		setImage( Cons.ALIEN_PURPLE );
		setPosition( x, y );
	}

	// ���W�X�V �ړ�����
    public void move( double time, String s ){
    	positionX += velocityX * time;
    	positionY += velocityY * time;

    	if( s == "UP"){
    		if( positionY < -100 ){
       			deadGO();
       		}
    	}else if( s == "DOWN"){
    		if( positionY > 640 ){
       			deadGO();
       		}
    	}else if( s == "RIGHT"){
    		if( positionX > 640 ){
       			deadGO();
       		}
    	}else if( s == "LEFT"){
    		if( positionX < -100 ){
       			deadGO();
       		}
    	}
    }

    // ��ʊO�ŃX�g���[�W��
   	public void outFrameY(){
   		if( positionY > 1080 ){
   			deadGO();
   		}
   		if( positionY < -540 ){
   			deadGO();
   		}
   	}
    // ��ʊO�ŃX�g���[�W��
   	public void outFrameX(){
   		if( positionX > 1080 ){
   			deadGO();
   		}
   		if( positionX < -540 ){
   			deadGO();
   		}
   	}
}
