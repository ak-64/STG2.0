package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class InitTitle {
	Group root = Main.root;
	InitTitle(){}
	public void setTitle(){
		
		Label label1 = new Label( "THE SHOOTING" );
		Label label2 = new Label( "PRESS SPACE KEY" );
		
		BorderPane pane = new BorderPane();
		Background back = new Background( new BackgroundFill( Color.web( "#ffffff" ) , null , null ) );
		Label title = label1;
		Label bottom = label2;
		
		title.setFont( Font.font( "IMPACT", 50 ) );
        bottom.setFont( Font.font( "IMPACT", 30 ) );
        title.setTextFill( Color.web( "#0076a3" ) );
        bottom.setTextFill( Color.web( "#0076a3" ) );
        BorderPane.setAlignment( title , Pos.CENTER );
        BorderPane.setAlignment( bottom , Pos.CENTER );
        BorderPane.setMargin( title , new Insets( 0, 0, 0, 0 ) );
        BorderPane.setMargin( bottom , new Insets( 0, 0, 100, 0 ) );
        pane.setPrefSize( Cons.FRAME_W, Cons.FRAME_H );
        pane.setBackground( back );
        pane.setCenter( title );
        pane.setBottom( bottom );
        root.getChildren().add( pane );
	}
}
