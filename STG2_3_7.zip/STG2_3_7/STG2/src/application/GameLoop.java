package application;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

public class GameLoop extends AnimationTimer{
	GraphicsContext gc;
	int timeFlagInvader = 0;
	int scoreUPflag = 0;
	long lastNanoTime = System.nanoTime();
	long lastTime = System.nanoTime();
	long fpsCount;
	long lastBeam;
	double timeLine;
	double elapsedTime;
	double tatalTime;
	double oneSecFlag;
	double loopTime;
	double loopTime2;
	double slant = Math.sqrt( 2 ) / 2 * Cons.SPEED_P;
	double backFlag = 0;
	String fps;
	String totalTimeStr;
	String score;
	Image playerImage;
	PlayerSprite player;
	BeamSprite[] beam;
	CreatAlienInvader stage1;
	CreatAlienStraight stage2;
	CreatAlienFormation stage3;
	CreatAlienFormationSide stage4;
	CreatAlienFormationAll stage5;
	CreatAlienBoss stage6;

//�@�R���X�g���N�^
	GameLoop(){
		Canvas canvas = new Canvas( Cons.FRAME_W, Cons.GAME_H );
		canvas.setTranslateX( 0 );
		canvas.setTranslateY( Cons.TOP_BAR );
		Main.root.getChildren().add( canvas );
		gc = canvas.getGraphicsContext2D();
		initObj();
	}

// �I�u�W�F�N�g����
	public void initObj(){
		Cons.HP = Cons.HP_MAX;
		Cons.HP_BOSS = Cons.HP_MAX_BOSS;
		Cons.DAMAGE_FLAG = 0;
		Cons.SCORE = 0;
		Cons.STAGE_CLEAR = 0;
		Cons.STAGE_FLAG = 1;
		Cons.CLEAR = 0;

		oneSecFlag = 0;
		timeFlagInvader = 0;
		playerImage = new Image( Cons.PLAYER_IMAGE );
		player = new PlayerSprite();
		beam = new BeamSprite[ Cons.B_NUM ];
        // �v���C���[�e�𐶐�
        for (int i = 0; i < Cons.B_NUM; i++){
            beam[ i ] = new BeamSprite();
        }
        initAlien();
    }

//�@���[�v
	public void handle( long currentNanoTime ){
		oneLoopClac( currentNanoTime );
	     // TOP
		fpsClac();
		timeClac();
		scoreClac();
		InitTopBar.getHP1();
		InitTopBar.getHP2();
		// �ĕ`��
        GCClear();
        //�@��ʑJ��
		gameOver();
		// �ړ��v�Z�@�v���C���[�ƃr�[��
        playerPosition( elapsedTime );
        beamPosition( elapsedTime );
        creatLoop();
    }

////////////////////////////////////////////////////////////////////

// �G�C���A������
	public void initAlien(){
		stage1 = new CreatAlienInvader();
		stage2 = new CreatAlienStraight();
		stage3 = new CreatAlienFormation( player );
		stage4 = new CreatAlienFormationSide( player );
		stage5 = new CreatAlienFormationAll( player );
		stage6 = new CreatAlienBoss( player );
	}
// �����^�C�����C��
	public void creatLoop(){

//+++++++++++++++++ �X�e�[�W�P +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 1 ){
			stage1.summon( elapsedTime, beam, player, gc );
			if( stage1.allDeadAlien() ){
				Cons.STAGE_CLEAR = 1;
			}
		}
//+++++++++++++++++ �N���A +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 1 && Cons.STAGE_CLEAR == 1 ){
			timeFlagInvader += 1;
			Cons.SCORE += 10;
		}

		if( Cons.STAGE_FLAG == 1 && timeFlagInvader > 200 ){
			Cons.STAGE_FLAG = 2;
			Cons.STAGE_CLEAR = 0;
		}
//+++++++++++++++++ �X�e�[�W�Q +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 2 && Cons.STAGE_CLEAR == 0 ){
			timeFlagInvader = 200;
			stage2.summon( elapsedTime, beam, player, gc );
			if( stage2.allDeadAlien() ){
				Cons.STAGE_CLEAR = 1;
			}
		}
//++++++++++++++++++++++++++++++++++ �N���A +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 2 && Cons.STAGE_CLEAR == 1 ){
			timeFlagInvader += 1;
			Cons.SCORE += 10;
		}

		if( Cons.STAGE_FLAG == 2 && timeFlagInvader > 400  ){
			Cons.STAGE_CLEAR = 0;
			Cons.STAGE_FLAG = 3;
			stage3.beamCapCreat();
		}
//+++++++++++++++++ �X�e�[�W�R +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 3 && Cons.STAGE_CLEAR == 0 ){
			timeFlagInvader = 400;
			stage3.summon( elapsedTime, beam, player, gc );
			if( stage3.allDeadAlien() ){
				Cons.STAGE_CLEAR = 1;
			}
		}
//++++++++++++++++++++++++++++++++++ �N���A +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 3 && Cons.STAGE_CLEAR == 1 ){
			timeFlagInvader += 1;
			Cons.SCORE += 10;
		}

		if( Cons.STAGE_FLAG == 3 && timeFlagInvader > 450  ){
			Cons.STAGE_CLEAR = 0;
			Cons.STAGE_FLAG = 4;
			stage4.beamCapCreat();
		}
//+++++++++++++++++ �X�e�[�W�S +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 4 && Cons.STAGE_CLEAR == 0 ){
			timeFlagInvader = 450;
			stage4.summon( elapsedTime, beam, player, gc );
			if( stage4.allDeadAlien() ){
				Cons.STAGE_CLEAR = 1;
			}
		}
//++++++++++++++++++++++++++++++++++ �N���A +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 4 && Cons.STAGE_CLEAR == 1 ){
			timeFlagInvader += 1;
			Cons.SCORE += 10;
		}

		if( Cons.STAGE_FLAG == 4 && timeFlagInvader > 500  ){
			Cons.STAGE_CLEAR = 0;
			Cons.STAGE_FLAG = 5;
			stage5.beamCapCreat1();
		}
//+++++++++++++++++++++++++ �X�e�[�W�T +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 5 && Cons.STAGE_CLEAR == 0 ){
			timeFlagInvader = 500;
			stage5.summon( elapsedTime, beam, player, gc );
			if( stage5.allDeadAlien() ){
				Cons.STAGE_CLEAR = 1;
			}
		}
//+++++++++++++++++++++++++ �N���A +++++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 5 && Cons.STAGE_CLEAR == 1 ){
			timeFlagInvader += 1;
			Cons.SCORE += 10;
		}
		if( Cons.STAGE_FLAG == 5 && timeFlagInvader > 550  ){
			Cons.STAGE_CLEAR = 0;
			Cons.STAGE_FLAG = 6;
		}
//+++++++++++++++++++++++++ �X�e�[�W�U +++++++++++++++++++++++++++//
		if( Cons.STAGE_FLAG == 6 && Cons.STAGE_CLEAR == 0 ){
			timeFlagInvader = 600;
			InitTopBar.pb2.setVisible( true );
			stage6.summon( tatalTime, elapsedTime, beam, player, gc );
		}
	}
///////////////////////////////////////////////////////////////

// ��ʃN���A �� �ĕ`��
	public void GCClear(){
		// ��ʃN���A
        gc.clearRect( 0, 0, Cons.FRAME_W, Cons.FRAME_H );
        gc.setFill( Color.web( "#000000" ) );
        gc.fillRect( 0, 0, Cons.FRAME_W, Cons.FRAME_H - Cons.TOP_BAR );

        playerNoDamage();
        objView();

	}

// �o�ߎ��Ԍv�Z
	public void oneLoopClac( long currentNanoTime ){
		// 1���[�v�o�ߎ���
		elapsedTime = ( currentNanoTime - lastNanoTime ) / 1000000000.0;
        lastNanoTime = currentNanoTime;
        oneSecFlag += elapsedTime;
        // �g�[�^���o�ߎ���
        tatalTime = ( currentNanoTime - lastTime ) / 1000000000.0;
        // ���[�v�J�E���g
		fpsCount++;
	}

// �g�[�^�����Ԍv�Z
	public void timeClac(){
		totalTimeStr = String.format( "%.1f", tatalTime );
		InitTopBar.timeText( totalTimeStr );
	}

// fps�v�Z
	public void fpsClac(){
		if( oneSecFlag > 0.5 ){
			fps = String.format( "%.1f", fpsCount / oneSecFlag );
			fpsCount = 0;
			oneSecFlag = 0;
			InitTopBar.fpsText( fps );
		}
	}
// �X�R�A�v�Z
	public void scoreClac(){
		score = String.valueOf( Cons.SCORE );
		InitTopBar.scoreText( score );
	}

// �v���C���[�_�Ŗ��G�@�`��
	public void playerNoDamage(){
		if( Cons.DAMAGE_FLAG == 1 ){
			loopTime += elapsedTime;
			loopTime2 += elapsedTime;
			if( loopTime > 0.05 ){
				loopTime = 0;
				gc.drawImage( playerImage, player.positionX -5 , player.positionY -5 );
				player.render( gc );
			}
			if( loopTime2 > 2 ){
				Cons.DAMAGE_FLAG = 0;
				loopTime2 = 0;
			}
		}else{
			gc.drawImage( playerImage, player.positionX -5 , player.positionY -5 );
        	player.render( gc );
        }
	}

//�@�z��̕`��
	public void objView(){
		// ���݂̃v���C���[�e�̈ʒu�ōĕ`��
		for( int i = 0; i < Cons.B_NUM; i++ ){
    		beam[ i ].render( gc );
		}
	}

// �v���C���[�̑J��
	public void playerPosition ( double time ){
		// ���[�v�����������Ă�����Ƃ�������
	    player.setVelocity( 0, 0 );

	    if( Key.input.contains( "UP" ) && Key.input.contains( "LEFT" ) ){
			player.addVelocity( -slant, -slant );
	    }else if( Key.input.contains( "UP" ) && Key.input.contains( "RIGHT" ) ){
			player.addVelocity( slant, -slant );
	    }else if( Key.input.contains( "DOWN" ) && Key.input.contains( "LEFT" ) ){
			player.addVelocity( -slant, slant );
	    }else if( Key.input.contains( "DOWN" ) && Key.input.contains( "RIGHT" ) ){
			player.addVelocity( slant, slant );
	    }else if( Key.input.contains( "UP" ) ){
            player.addVelocity( 0, - Cons.SPEED_P );
    	}else if( Key.input.contains( "DOWN" ) ){
            player.addVelocity( 0, Cons.SPEED_P );
        }else if( Key.input.contains( "LEFT" ) ){
    		player.addVelocity( -Cons.SPEED_P, 0 );
    	}else if( Key.input.contains( "RIGHT" ) ){
    		player.addVelocity( Cons.SPEED_P, 0 );
    	}

        if( Key.input.contains( "SPACE" ) ){
            player.slowMove();
        }
        // �ړ������v�Z 1���[�v����(��0.01�b) * 50
        player.move( time );
	}

// �v���C���[�r�[���̑J��
	public void beamPosition ( double time ){
		//�@�r�[���C���^�[�o���̏ꍇ
		if( System.currentTimeMillis() - lastBeam < Cons.B_INTERVAL ){
			for( int i = 0; i < Cons.B_NUM; i++ ){
				beam[ i ].move( time );
			}
			return;
		}
		lastBeam = System.currentTimeMillis();
		//�@�r�[���J��
		for( int i = 0; i < Cons.B_NUM; i++ ){

			if( beam[ i ].inStorage() ){
				beam[ i ].setVelocity( 0, 0 );
	            beam[ i ].addVelocity( 0, - ( Cons.SPEED_B ) );
	            beam[ i ].beamGo( player );
	            break;
	        }
		}
		for( int i = 0; i < Cons.B_NUM; i++ ){
        	beam[ i ].move( time );
		}
	}

// GAMEOVER����@+�@GAMEOVER��ʑJ��
	public void gameOver(){
		if( Cons.HP <= 0 || Cons.CLEAR == 1 ){
    		Main.initEnd();
    		this.stop();
		}
	}
}