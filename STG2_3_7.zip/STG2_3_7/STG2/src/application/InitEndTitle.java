package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class InitEndTitle {
	Group root = Main.root;
	InitEndTitle(){}
	
	public void setEnd(){
		Label title;
		Label bottom;
		Label score = new Label( "SCORE   " + String.valueOf( Cons.SCORE ) );
		BorderPane pane = new BorderPane();
		Background back = new Background( new BackgroundFill( Color.web( "#ffffff" ) , null , null ) );
		
		if( Cons.HP == 0 ){
			title = new Label( "GAME OVER" );
			bottom = new Label( "PRESS SPACE KEY" );
		}else{
			title = new Label( "GAME CLEAR" );
			bottom = new Label( "PRESS SPACE KEY" );
		}

		title.setFont( Font.font( "IMPACT", 50 ) );
		title.setTextFill( Color.web( "#0076a3" ) );
        bottom.setFont( Font.font( "IMPACT", 30 ) );
        bottom.setTextFill( Color.web( "#0076a3" ) );
        score.setFont( Font.font( "IMPACT", 50 ) );
        score.setTextFill( Color.web( "#0076a3" ) );
		
        VBox vboxT = new VBox();
        title.setAlignment( Pos.CENTER );
        score.setAlignment( Pos.CENTER );
        vboxT.setAlignment( Pos.CENTER );
        BorderPane.setAlignment( bottom , Pos.CENTER );
        BorderPane.setAlignment( vboxT , Pos.CENTER );
        //BorderPane.setMargin( vboxT , new Insets( 50, 0, 0, 0 ) );
        BorderPane.setMargin( bottom , new Insets( 0, 0, 100, 0 ) );
        
        vboxT.getChildren().addAll( title, score );
        pane.setPrefSize( Cons.FRAME_W, Cons.FRAME_H );
        pane.setBackground( back );
        //pane.setTop( vboxT );
        pane.setCenter( vboxT );
        pane.setBottom( bottom );
        

        root.getChildren().add( pane );
        
	}

	public void setEnd2(){
		Label title;
		Label bottom;
		Label score = new Label( "SCORE   " + String.valueOf( Cons.SCORE ) );

		Label ten[] = new Label[10];
		for( int i = 0; i < 10; i++ ){
			ten[ i ] = new Label( "RANK " + String.valueOf( i + 1 ) );
			ten[ i ].setFont( Font.font( "IMPACT", 25 ) );
			ten[ i ].setTextFill( Color.web( "#0076a3" ) );
			ten[ i ].setAlignment( Pos.CENTER_LEFT );
		}

		Label dCollon[] = new Label[10];
		for( int i = 0; i < 10; i++ ){
			dCollon[ i ] = new Label( ":" );
			dCollon[ i ].setFont( Font.font( "IMPACT", 25 ) );
			dCollon[ i ].setTextFill( Color.web( "#0076a3" ) );
			dCollon[ i ].setAlignment( Pos.CENTER_RIGHT );
		}

		if( Cons.HP == 0 ){
			title = new Label( "GAME OVER" );
			bottom = new Label( "PRESS SPACE KEY" );
		}else{
			title = new Label( "GAME CLEAR" );
			bottom = new Label( "PRESS SPACE KEY" );
		}

		BorderPane pane = new BorderPane();
		Background back = new Background( new BackgroundFill( Color.web( "#ffffff" ) , null , null ) );
		HBox hbox1 = new HBox();
		VBox vbox1 = new VBox();
		VBox vbox2 = new VBox();
		VBox vbox3 = new VBox();
		VBox vbox4 = new VBox();
		VBox vbox5 = new VBox();
		VBox vbox6 = new VBox();
		VBox vboxT = new VBox();

		title.setFont( Font.font( "IMPACT", 50 ) );
		title.setTextFill( Color.web( "#0076a3" ) );
        bottom.setFont( Font.font( "IMPACT", 30 ) );
        bottom.setTextFill( Color.web( "#0076a3" ) );

        score.setFont( Font.font( "IMPACT", 50 ) );
        score.setTextFill( Color.web( "#0076a3" ) );

        vbox1.setAlignment( Pos.CENTER );
        vbox2.setAlignment( Pos.CENTER_RIGHT );
        vbox3.setAlignment( Pos.CENTER_LEFT );
        vbox4.setAlignment( Pos.CENTER_RIGHT );
        vbox5.setAlignment( Pos.CENTER );
        vbox6.setAlignment( Pos.CENTER );

        vboxT.setAlignment( Pos.CENTER );
        hbox1.setAlignment( Pos.CENTER );
        BorderPane.setAlignment( bottom , Pos.CENTER );

        BorderPane.setMargin( vboxT , new Insets( 50, 0, 0, 0 ) );
        BorderPane.setMargin( bottom , new Insets( 0, 0, 100, 0 ) );

        hbox1.setSpacing(10);
        vbox5.setPadding(new Insets( 0, -10, 0, -10));

        vbox1.getChildren().addAll( ten[0], ten[1], ten[2], ten[3], ten[4] );
        vbox5.getChildren().addAll( dCollon[0], dCollon[1], dCollon[2], dCollon[3], dCollon[4] );
        vbox2.getChildren().addAll( Ranking.ranking[0], Ranking.ranking[1], Ranking.ranking[2], Ranking.ranking[3], Ranking.ranking[4] );
        vbox3.getChildren().addAll( ten[5], ten[6], ten[7], ten[8], ten[9] );
        vbox6.getChildren().addAll( dCollon[5], dCollon[6], dCollon[7], dCollon[8], dCollon[9] );
        vbox4.getChildren().addAll( Ranking.ranking[5], Ranking.ranking[6], Ranking.ranking[7], Ranking.ranking[8], Ranking.ranking[9] );
        hbox1.getChildren().addAll( vbox1, vbox5, vbox2, vbox3, vbox6, vbox4 );

        vboxT.getChildren().addAll( title, score );
        pane.setPrefSize( Cons.FRAME_W, Cons.FRAME_H );
        pane.setBackground( back );
        pane.setTop( vboxT );
        pane.setBottom( bottom );
        pane.setCenter( hbox1 );

        root.getChildren().add( pane );

	}
}
