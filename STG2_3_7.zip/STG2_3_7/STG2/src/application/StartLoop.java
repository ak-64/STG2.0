package application;

import javafx.animation.AnimationTimer;

public class StartLoop extends AnimationTimer{
	long lastNanoTime = System.nanoTime();
	double elapsedTime;
	double sumTime = 0;
	
	public void handle( long currentNanoTime ){
		elapsedTime = ( currentNanoTime - lastNanoTime ) / 1000000000.0;
        lastNanoTime = currentNanoTime;
        sumTime += elapsedTime;
    	if( Key.input.contains( "SPACE" ) && sumTime > 0.5 ){
    		Main.initGame();
    		this.stop();
    	}
    }
}