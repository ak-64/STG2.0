package application;

import java.util.ArrayList;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;

public class Key{
	Scene scene;
	public static ArrayList< String > input = new ArrayList< String >();

	Key( Scene sc ){
		scene = sc;
		setKeyEvent();
	}

	public void setKeyEvent(){
		// SPACE�ȊO�i�[
        scene.setOnKeyPressed(
            new EventHandler< KeyEvent >(){
                public void handle( KeyEvent e ){
                    String code = e.getCode().toString();
                    if ( !input.contains( code ) ){
                    	input.add( code );
					}

                }
            }
		);

        scene.setOnKeyReleased(
            new EventHandler< KeyEvent >(){
                public void handle( KeyEvent e ){
                    String code = e.getCode().toString();
                    input.remove( code );
                }
            }
		);
	}
}