package application;

import java.util.Random;

public class BeamCrossSprite extends BeamSprite{
	double storageX = -100;
	double storageY = -100;
	static int flag = 0;
	static Random rand = new Random();
	BeamCrossSprite( String s ){
		super();
        setImage( s );
        setPosition( storageX, storageY );
	}
	
	public static void flagCross(){
		flag = rand.nextInt( 3 );
	}

	public void beamGo1( int i ){
		if( flag == 0 ){
			if( i == 13 ){
				positionX = ( 24 * 22 );
				positionY = -500;
			}else{
				positionX = ( 24 * i );
				positionY = -500;
			}
		}
		
		if( flag == 1 ){
			if( i == 15 ){
				positionX = ( 24 * 22 );
				positionY = -500;
			}else{
				positionX = ( 24 * i );
				positionY = -500;
			}
		}
		
		if( flag == 2 ){
			if( i == 21 ){
				positionX = ( 24 * 22 );
				positionY = -500;
			}else{
				positionX = ( 24 * i );
				positionY = -500;
			}
		}
	}
	
	public void beamGo2( int i ){
		if( flag == 0 ){
			if( i == 13 ){
				positionX = -500;
				positionY = ( 24 * 22 );
			}else{
				positionX = -500;
				positionY = ( 24 * i );
			}
		}
		
		if( flag == 1 ){
			if( i == 15 ){
				positionX = -500;
				positionY = ( 24 * 22 );
			}else{
				positionX = -500;
				positionY = ( 24 * i );
			}
		}
		
		if( flag == 2 ){
			if( i == 21 ){
				positionX = -500;
				positionY = ( 24 * 22 );
			}else{
				positionX = -500;
				positionY = ( 24 * i );
			}
		}
	}
	
// ��ʊO�ŃX�g���[�W��
 	public void outFrameBeam(){
 		if( positionX > 1080 ){
 			storageGO();
 		}
 		if( positionX < -540 ){
 			storageGO();
 		}
 		if( positionY > 1080 ){
 			storageGO();
 		}
 		if( positionY < -540 ){
 			storageGO();
 		}
 	}

// �X�g���[�W��
 	public void storageGO(){
 		setVelocity( 0, 0 );
 		setPosition( storageX, storageY );
 	}

// �e���ۊǏꏊ�ɂ���ΐ^
 	public boolean inStorage(){
 		if( ( positionX == storageX ) && ( positionY == storageY ) ){
 			return true;
 		}
 		return false;
 	}
}
