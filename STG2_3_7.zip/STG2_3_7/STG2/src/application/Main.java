package application;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application{
	private Scene scene = null;
	static Group root = new Group();
	
	@Override
	public void start( Stage stage )throws Exception{
		this.scene = new Scene( root, Cons.FRAME_W, Cons.FRAME_H, Color.WHITE );
		initStart();
		//initEnd();
		new Key( scene );
		stage.setTitle( "�V���[�e�B���O�Q�[��" );
		stage.setScene( scene );
		stage.show();
	}
	
// �X�^�[�g��ʑJ��
	public static void initStart(){
		new InitTitle().setTitle();
        new StartLoop().start();
	}

//�@�Q�[����ʑJ��
	public static void initGame(){
		new InitTopBar();
        new GameLoop().start();
	}
	
//�@�G���h��ʑJ��
	public static void initEnd(){
		//Ranking.tukareta();
		new InitEndTitle().setEnd();
        new EndLoop().start();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
