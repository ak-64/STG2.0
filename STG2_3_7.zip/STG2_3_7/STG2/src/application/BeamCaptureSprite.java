package application;

public class BeamCaptureSprite extends BeamSprite{
	double storageX = -100;
	double storageY = -100;
	double playerX;
	double playerY;
	double capX;
	double capY;
	double max;

	BeamCaptureSprite( Sprite sprite, Sprite player ){
		super();
		beamGo(sprite);
		beamCap(player);
        setImage( Cons.BEAM_BALL_PINK );
	}

	// ���ˎ��̃v���C���[���W�Ɍ�����
	public void beamCap( Sprite player ){
		playerX = player.positionX  + ( player.width / 2 );
		playerY = player.positionY  + ( player.height / 2 );
		capX = playerX - positionX;
		capY = playerY - positionY;
		max = Math.max( Math.abs( capX ), Math.abs( capY ) );
		capX = capX / max * 500;
		capY = capY / max * 500;

		setVelocity( capX, capY );
	}
	public void beamGo( Sprite sprite ){
		positionX = sprite.positionX + ( sprite.width / 2 ) - ( width / 2 ) -1;
		positionY = sprite.positionY + height ;
	}
// ��ʊO�ŃX�g���[�W��
 	public void outFrameBeam(){
 		if( positionX > 1080 ){
 			storageGO();
 		}
 		if( positionX < -540 ){
 			storageGO();
 		}
 		if( positionY > 1080 ){
 			storageGO();
 		}
 		if( positionY < -540 ){
 			storageGO();
 		}
 	}

// �X�g���[�W��
 	public void storageGO(){
 		setVelocity( 0, 0 );
 		setPosition( storageX, storageY );
 	}

// �e���ۊǏꏊ�ɂ���ΐ^
 	public boolean inStorage(){
 		if( ( positionX == storageX ) && ( positionY == storageY ) ){
 			return true;
 		}
 		return false;
 	}
}
