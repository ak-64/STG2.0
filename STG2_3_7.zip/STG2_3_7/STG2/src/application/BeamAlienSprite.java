package application;

public class BeamAlienSprite extends BeamSprite{
	double storageX = -100;
	double storageY = -100;
	BeamAlienSprite( String s ){
		super();
		setPosition( storageX, storageY );
        setImage( s );
	}
	
// ��ʊO�ŃX�g���[�W��
 	public void outFrameBeam(){
 		if( positionY > Cons.GAME_H ){
 			storageGO();
 		}
 	}

// �X�g���[�W��
 	public void storageGO(){
 		setVelocity( 0, 0 );
 		setPosition( storageX, storageY );
 	}

// �e���ۊǏꏊ�ɂ���ΐ^
 	public boolean inStorage(){
 		if( ( positionX == storageX ) && ( positionY == storageY ) ){
 			return true;
 		}
 		return false;
 	}
}
