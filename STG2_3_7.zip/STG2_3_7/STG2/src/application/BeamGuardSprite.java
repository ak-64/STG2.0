package application;

public class BeamGuardSprite extends BeamSprite{
	double storageX = -100;
	double storageY = -100;
	double sin;
	double cos;

// �R���X�g���N�^  �����ݒ�
	BeamGuardSprite(){
		super();
        setImage( Cons.BEAM_BALL_RED );
	}

	public void round1( double time, AlienBossSprite alien ){
		cos = Math.cos( ( time + Math.toRadians( 0 ) ) * 10 );
		sin = Math.sin( ( time + Math.toRadians( 0 ) ) * 10 );
		double x = ( alien.positionX + 2 ) + 20 * cos;
		double y = ( alien.positionY + 2 ) + 20 * sin;
		setPosition( x, y );
	}
	public void round2( double time, AlienBossSprite alien ){
		cos = Math.cos( ( time + Math.toRadians( 45 ) ) * 10 );
		sin = Math.sin( ( time + Math.toRadians( 45 ) ) * 10 );
		double x = ( alien.positionX + 2 ) + 20 * cos;
		double y = ( alien.positionY + 2 ) + 20 * sin;
		setPosition( x, y );
	}
	public void round3( double time, AlienBossSprite alien ){
		cos = Math.cos( ( time + Math.toRadians( 90 ) ) * 10 );
		sin = Math.sin( ( time + Math.toRadians( 90 ) ) * 10 );
		double x = ( alien.positionX + 2 ) + 20 * cos;
		double y = ( alien.positionY + 2 ) + 20 * sin;
		setPosition( x, y );
	}
	public void round4( double time, AlienBossSprite alien ){
		cos = Math.cos( ( time + Math.toRadians( 135 ) ) * 10 );
		sin = Math.sin( ( time + Math.toRadians( 135 ) ) * 10 );
		double x = ( alien.positionX + 2 ) + 20 * cos;
		double y = ( alien.positionY + 2 ) + 20 * sin;
		setPosition( x, y );
	}


// ���ˈʒu
	public void beamGo( Sprite sprite ){
		positionX = sprite.positionX + ( sprite.width / 2 ) - ( width / 2 ) -1;
		positionY = sprite.positionY + height ;
	}

// ��ʊO�ŃX�g���[�W��
 	public void outFrameBeam(){
 		if( positionX > 1080 ){
 			storageGO();
 		}
 		if( positionX < -540 ){
 			storageGO();
 		}
 		if( positionY > 1080 ){
 			storageGO();
 		}
 		if( positionY < -540 ){
 			storageGO();
 		}
 	}

// �X�g���[�W��
 	public void storageGO(){
 		setVelocity( 0, 0 );
 		setPosition( storageX, storageY );
 	}

// �e���ۊǏꏊ�ɂ���ΐ^
 	public boolean inStorage(){
 		if( ( positionX == storageX ) && ( positionY == storageY ) ){
 			return true;
 		}
 		return false;
 	}
}
