package application;

public class BeamVortexSprite extends BeamSprite{
	double storageX = -100;
	double storageY = -100;
	double cos;
	double sin;
	double spx;
	double spy;
	double speed = 1000;
	double x;
	double y;
	double c;
	double max;
	int setFlag = 0;
	int count1 = 0;

// �R���X�g���N�^  �����ݒ�
	BeamVortexSprite( Sprite sprite ){
		super();
		beamGo( sprite );
		sprite.setVelocity( -100, 0 );
        setImage( Cons.BEAM_BIG_RED );
	}
//

	// ���ˎ��̃v���C���[���W�Ɍ�����
	public void round7( double time, AlienBossSprite alien ){
		spx = -1;
		spy = 1;
		x = spx;
		y = spy;
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		x = x / max;
		y = y / max;
		c = Math.sqrt( x * x + y * y );
		x = x / c * speed;
		y = y / c * speed;
		setVelocity( x, y );
	}
	public void round6( double time, AlienBossSprite alien ){
		spx = -1;
		spy = 0;
		x = spx;
		y = spy;
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		x = x / max;
		y = y / max;
		c = Math.sqrt( x * x + y * y );
		x = x / c * speed;
		y = y / c * speed;
		setVelocity( x, y );
	}

	public void round5( double time, AlienBossSprite alien ){
		spx = -1;
		spy = -1;
		x = spx;
		y = spy;
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		x = x / max;
		y = y / max;
		c = Math.sqrt( x * x + y * y );
		x = x / c * speed;
		y = y / c * speed;
		setVelocity( x, y );
	}
	public void round4( double time, AlienBossSprite alien ){
		spx = 0;
		spy = -1;
		x = spx;
		y = spy;
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		x = x / max;
		y = y / max;
		c = Math.sqrt( x * x + y * y );
		x = x / c * speed;
		y = y / c * speed;
		setVelocity( x, y );
	}

	public void round3( double time, AlienBossSprite alien ){
		spx = 1;
		spy = -1;
		x = spx;
		y = spy;
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		x = x / max;
		y = y / max;
		c = Math.sqrt( x * x + y * y );
		x = x / c * speed;
		y = y / c * speed;
		setVelocity( x, y );
	}
	public void round2( double time, AlienBossSprite alien ){
		spx = 1;
		spy = 0;
		x = spx;
		y = spy;
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		x = x / max;
		y = y / max;
		c = Math.sqrt( x * x + y * y );
		x = x / c * speed;
		y = y / c * speed;
		setVelocity( x, y );
	}

	public void round1( double time, AlienBossSprite alien ){
		spx = 1;
		spy = 1;
		x = spx;
		y = spy;
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		max = Math.max( Math.abs( x ), Math.abs( y ) );
		x = x / max;
		y = y / max;
		c = Math.sqrt( x * x + y * y );
		x = x / c * speed;
		y = y / c * speed;
		setVelocity( x, y );
	}

	public void round0( double time, AlienBossSprite alien ){
		setVelocity( 0, speed );
		count1++;
	}

// big ���@�{�X�̂Ƃ���ɂ����true
	public boolean inAlien( AlienSprite alien ){
		if( alien.positionX == positionX && alien.positionY == positionY ){
			return true;
		}
		return false;
	}

// ���ˈʒu
	public void beamGo( Sprite sprite ){
		positionX = sprite.positionX - 20;
		positionY = sprite.positionY + sprite.height ;
	}

// ��ʊO�ŃX�g���[�W��
 	public void outFrameBeam(){
 		if( positionX > 540 ){
 			storageGO();
 		}
 		if( positionX < 0 ){
 			storageGO();
 		}
 		if( positionY > 540 ){
 			storageGO();
 		}
 		if( positionY < 0 ){
 			storageGO();
 		}
 	}

// �X�g���[�W��
 	public void storageGO(){
 		setVelocity( 0, 0 );
 		setPosition( storageX, storageY );
 	}

// �e���ۊǏꏊ�ɂ���ΐ^
 	public boolean inStorage(){
 		if( ( positionX == storageX ) && ( positionY == storageY ) ){
 			return true;
 		}
 		return false;
 	}
}
