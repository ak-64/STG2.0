package application;

import java.util.Random;

import javafx.scene.canvas.GraphicsContext;

public class CreatAlienBoss {
	int ALIEN = 1;
	int BEAMGUARD = 4;
	int BEAMBIG1 = 7;
	int BEAMBIG2 = 6;
	int BEAMGUIDE = 15;
	int BEAMCROSS = 22;
	int BEAMVORTEX = 8;
	int con1 = 0;
	int storageflag = 0;
	int stageCount = 450;
	int flagstage = 0;
	int clearFlag = 0;
	int bossDeleteFlag = 0;
	double beamSpeed = 500;
	double loopTime = 0;
	double loopTime2 = 0;
	AlienBossSprite alien;
	BeamGuardSprite[] beamGurad;
	BeamBigSprite[] beamBig1;
	BeamBigSprite[] beamBig2;
	BeamBigSprite[] beamBig3;
	BeamBigSprite[] beamBig4;
	BeamBigSprite[] beamBig5;
	BeamGuideSprite[] beamGuide1;
	BeamCrossSprite[] beamCross1;
	BeamCrossSprite[] beamCross2;
	BeamVortexSprite[] beamVortex;
	PlayerSprite player;
	Random rand = new Random();

	CreatAlienBoss( PlayerSprite play ){
		con1 = 0;
		Cons.HP_BOSS = Cons.HP_MAX_BOSS;
		player = play;
		beamGurad = new BeamGuardSprite[ BEAMGUARD ];
		beamBig1 = new BeamBigSprite[ BEAMBIG1 ];
		beamBig2 = new BeamBigSprite[ BEAMBIG2 ];
		beamBig3 = new BeamBigSprite[ BEAMBIG1 ];
		beamBig4 = new BeamBigSprite[ BEAMBIG2 ];
		beamBig5 = new BeamBigSprite[ BEAMBIG1 ];
		beamGuide1 = new BeamGuideSprite[ BEAMGUIDE ];
		beamCross1 = new BeamCrossSprite[ BEAMCROSS ];
		beamCross2 = new BeamCrossSprite[ BEAMCROSS ];
		beamVortex = new BeamVortexSprite[ BEAMVORTEX ];
		alien = new AlienBossSprite();

		// �G�C���A���e�𐶐�
        for ( int i = 0; i < BEAMGUARD; i++ ){
        	beamGurad[ i ] = new BeamGuardSprite();
        }
        for ( int i = 0; i < BEAMBIG1; i++ ){
        	beamBig1[ i ] = new BeamBigSprite( alien );
        	beamBig3[ i ] = new BeamBigSprite( alien );
        	beamBig5[ i ] = new BeamBigSprite( alien );
        }
        for ( int i = 0; i < BEAMBIG2; i++ ){
        	beamBig2[ i ] = new BeamBigSprite( alien );
        	beamBig4[ i ] = new BeamBigSprite( alien );
        }
        for ( int i = 0; i < BEAMGUIDE; i++ ){
        	beamGuide1[ i ] = new BeamGuideSprite( alien ,player );
        }
        for ( int i = 0; i < BEAMCROSS; i++ ){
        	beamCross1[ i ] = new BeamCrossSprite( Cons.BEAM_LONG_COLORFUL );
        	beamCross2[ i ] = new BeamCrossSprite( Cons.BEAM_LONG_SIDE_COLORFUL );
        }
        for ( int i = 0; i < BEAMVORTEX; i++ ){
        	beamVortex[ i ] = new BeamVortexSprite( alien );
        }

	}

// �G�C���A���̑J��
	public void alienPosition( double time ){
		alien.move( time );
	}

// �Փ˔��� �G�C���A�� -> �v���C���[
	public void collisionAp( PlayerSprite player ){
		if( Cons.DAMAGE_FLAG == 0 ){
			for( int i = 0; i < ALIEN; i++ ){
				// ����ł��烋�[�v������
				if( alien.inStorage() ){
					continue;
				}
				if( alien.intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
					break;
				}
			}
		}
	}

// �Փ˔��� �v���C���[�r�[�� -> �G�C���A��
	public void collisionAb( BeamSprite[] beam ){
		for( int j = 0; j < Cons.B_NUM; j++ ){
			if( alien.intersects( beam[ j ] ) ){
				alien.damage();
				beam[ j ].storageGO();
				Cons.SCORE += 1120;
				break;
			}
		}
	}

	public void summon( double tatalTime, double time, BeamSprite[] beamPlayer, PlayerSprite play, GraphicsContext gc ){
		player = play;

		if( clearFlag == 0 ){
			//�@�Փ˔���@�{�X��P�r�[��
			collisionAb( beamPlayer );
			//�@�Փ˔���@�{�X�ƃv���C���[
			collisionAp( player );
			//�@�G�C���A���K�[�h
			alienGuard( tatalTime, beamPlayer, gc );

			if( stageCount == 450 ){
				flagstage = rand.nextInt( 4 );
				stageCount = 0;
			}

			if( flagstage == 0 ){
				//�@�G�C���A�����H���e�N�X
				alienVortex( tatalTime, time, gc );
			}
			if( flagstage == 1 ){
				// �G�C���A���r�b�O�t�H�[��
				if( stageCount == 0 ){
					initBigFall();
					con1 = 0;
					for( int i = 0; i < BEAMBIG1; i++ ){
						beamBig1[ i ].beamGo( alien );
						beamBig3[ i ].beamGo( alien );
						beamBig5[ i ].beamGo( alien );
					}
					for( int i = 0; i < BEAMBIG2; i++ ){
						beamBig2[ i ].beamGo( alien );
						beamBig4[ i ].beamGo( alien );
					}
				}
				alienBig( tatalTime, time, beamPlayer, gc );
			}
			if( flagstage == 2 ){
				// �G�C���A���K�C�h
				if( stageCount == 0 ){
					for( int i = 0; i < BEAMGUIDE; i++ ){
						beamGuide1[ i ].storageGO();
					}
				}
				alienGuide( tatalTime, time, beamPlayer, gc );
			}
			if( flagstage == 3 ){
				// �G�C���A���N���X
				alienCross( time, gc );
			}

			alien.render( gc );
			//�@�{�X���S�m�F
			deadAlien();
		}else{
			bossClear( time, gc );
		}
		stageCount++;
	}

// �{�X�_�ŕ`��
	public void bossClear( double elapsedTime, GraphicsContext gc ){
		loopTime += elapsedTime;
		loopTime2 += elapsedTime;
		bossDeleteFlag++;
		Cons.SCORE += 2000;

		if( loopTime > 0.15 && bossDeleteFlag < 60 ){
			loopTime = 0;
			alien.render( gc );
		}

		if( loopTime > 0.05   && bossDeleteFlag > 60 && bossDeleteFlag < 120 ){
			loopTime = 0;
			alien.render( gc );
		}

		if( loopTime2 > 2 && bossDeleteFlag == 180 ){
			Cons.CLEAR = 1;
			bossDeleteFlag = 0;
		}
	}

//////////////////////////////  �{���e�N�X�r�[��  //////////////////////////////////////////////////////
	public void alienVortex( double totaltime, double time, GraphicsContext gc ){
		beamAlienVortex( totaltime, time );
		collisionAVp( player );
		alienMove( time );
		for( int i = 0; i < BEAMVORTEX; i++ ){
			beamVortex[ i ].render( gc );
		}
	}
	public void alienMove( double time ){
		if( alien.positionX > 500 ){
			alien.setVelocity( -100, 0 );
		}
		if( alien.positionX < 40 ){
			alien.setVelocity( 100, 0 );
		}
		alien.move( time );
	}

	public void beamAlienVortex( double totaltime, double time ){
		beamVortex[ 0 ].round0( totaltime, alien );
		beamVortex[ 1 ].round1( totaltime, alien );
		beamVortex[ 2 ].round2( totaltime, alien );
		beamVortex[ 3 ].round3( totaltime, alien );
		beamVortex[ 4 ].round4( totaltime, alien );
		beamVortex[ 5 ].round5( totaltime, alien );
		beamVortex[ 6 ].round6( totaltime, alien );
		beamVortex[ 7 ].round7( totaltime, alien );
		for( int i = 0; i < BEAMVORTEX; i++ ){
			if( !beamVortex[ i ].inStorage() ){
				beamVortex[ i ].move( time );
			}else{
				storageflag += 1;
			}
		}
		if( storageflag == 8 ){
			for( int i = 0; i < BEAMVORTEX; i++ ){
				beamVortex[ i ].beamGo( alien );
			}
		}
		storageflag = 0;
	}
// �Փ˔��� �G�C���A���K�C�h -> �v���C���[
	public void collisionAVp( PlayerSprite player ){
		if( Cons.DAMAGE_FLAG == 0 ){
 			for( int i = 0; i < BEAMVORTEX; i++ ){
				// ���[�v������
				if( beamVortex[ i ].inStorage() ){
					continue;
				}
				if( beamVortex[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
		}
	}



/////////////////////////  �N���X�r�[��  ////////////////////////////////////////////////////
	public void alienCross( double time, GraphicsContext gc ){

		beamAlienCross1( time );
		beamAlienCross2( time );
		collisionACCp1( player );
		collisionACCp2( player );

		for( int i = 0; i < BEAMCROSS; i++ ){
			beamCross1[ i ].render( gc );
			beamCross2[ i ].render( gc );
		}
	}

	public void beamAlienCross1( double time ){
		for( int i = 0; i < BEAMCROSS; i++ ){
			if( beamCross1[ i ].inStorage() ){
				if( i == 0 ){
					BeamCrossSprite.flagCross();
				}
				beamCross1[ i ].setVelocity( 0, 200 );
				beamCross1[ i ].beamGo1( i );
			}
			beamCross1[ i ].move( time );
		}
	}
	public void beamAlienCross2( double time ){
		for( int i = 0; i < BEAMCROSS; i++ ){
			if( beamCross2[ i ].inStorage() ){
				if( i == 0 ){
					BeamCrossSprite.flagCross();
				}
				beamCross2[ i ].setVelocity( 200, 0 );
				beamCross2[ i ].beamGo2( i );
			}
			beamCross2[ i ].move( time );
		}
	}

	// �Փ˔��� �G�C���A���K�C�h -> �v���C���[
	public void collisionACCp1( PlayerSprite player ){
		if( Cons.DAMAGE_FLAG == 0 ){
 			for( int i = 0; i < BEAMCROSS; i++ ){
				// ���[�v������
				if( beamCross1[ i ].inStorage() ){
					continue;
				}
				if( beamCross1[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
		}
	}

	// �Փ˔��� �G�C���A���K�C�h -> �v���C���[
		public void collisionACCp2( PlayerSprite player ){
			if( Cons.DAMAGE_FLAG == 0 ){
	 			for( int i = 0; i < BEAMCROSS; i++ ){
					// ���[�v������
					if( beamCross2[ i ].inStorage() ){
						continue;
					}
					if( beamCross2[ i ].intersects( player ) ){
						Cons.HP--;
						Cons.DAMAGE_FLAG = 1;
					}
				}
			}
		}

///////////////////////// �G�C���A���K�C�h�r�[�� //////////////////////////////////////////
	public void alienGuide( double tatalTime, double time, BeamSprite[] beamPlayer, GraphicsContext gc ){

		beamAlienGuide( time );
		collisionAGGp( player );
		collisionAGGpb( beamPlayer );
		for( int i = 0; i < BEAMGUIDE; i++ ){
			beamGuide1[ i ].render( gc );
		}
	}

	// �G�C���A���K�C�h�̑J��
		public void beamAlienGuide( double time ){
			for( int i = 0; i < BEAMGUIDE; i++ ){
				if( beamGuide1[ i ].inStorage() ){
					if( rand.nextInt( 50 ) == 0 ){
						beamGuide1[ i ].beamGo( i );
						beamGuide1[ i ].beamCap( player );
					}
				}
				beamGuide1[ i ].move( time );
			}
		}

	// �Փ˔��� �G�C���A���K�C�h -> �v���C���[
		public void collisionAGGp( PlayerSprite player ){
			if( Cons.DAMAGE_FLAG == 0 ){
	 			for( int i = 0; i < BEAMGUIDE; i++ ){
					// ���[�v������
					if( beamGuide1[ i ].inStorage() ){
						continue;
					}
					if( beamGuide1[ i ].intersects( player ) ){
						Cons.HP--;
						Cons.DAMAGE_FLAG = 1;
					}
				}
			}
		}
		
	// �Փ˔��� �G�C���A���K�C�h -> �v���C���[�r�[��
			public void collisionAGGpb( BeamSprite[] beamPlayer ){	 			
	 			for( int i = 0; i < BEAMGUIDE; i++ ){
	 				for( int j = 0; j < Cons.B_NUM; j++ ){
	 					if( beamGuide1[ i ].intersects( beamPlayer[ j ] ) ){
	 						beamPlayer[ j ].storageGO();
	 						beamGuide1[ i ].storageGO();
	 					}
	 				}
	 			}
			}
		

//////////////////////////�@�G�C���A���r�b�O�r�[���@////////////////////////////////////////
	public void alienBig( double tatalTime, double time, BeamSprite[] beamPlayer, GraphicsContext gc ){

		beamAlienBig( time );
		collisionABp( player );
		for( int i = 0; i < BEAMBIG1; i++ ){
			beamBig1[ i ].render( gc );
			beamBig3[ i ].render( gc );
			beamBig5[ i ].render( gc );
		}
		for( int i = 0; i < BEAMBIG2; i++ ){
			beamBig2[ i ].render( gc );
			beamBig4[ i ].render( gc );
		}
	}
// �G�C���A���r�b�O�̑J��
	public void beamAlienBig( double time ){
		con1++;

		for( int i = 0; i < BEAMBIG1; i++ ){
			if( beamBig1[ i ].inStorage() ){
				break;
			}
			// big���㕔�܂ł�������
			if( con1 > 100 ){
				beamBig1[ i ].setFlag = 1;
			}
			if( beamBig1[ i ].setFlag == 0 ){
				beamBig1[ i ].setBigFall1( i );
			}else{
				beamBig1[ i ].goBigFall();
			}
			beamBig1[ i ].move( time );
		}

		if( con1 > 50 ){
			for( int i = 0; i < BEAMBIG2; i++ ){
				if( beamBig2[ i ].inStorage() ){
					break;
				}
				// big���㕔�܂ł�������
				if( con1 > 150 ){
					beamBig2[ i ].setFlag = 1;
				}
				if( beamBig2[ i ].setFlag == 0 ){
					beamBig2[ i ].setBigFall2( i );
				}else{
					beamBig2[ i ].goBigFall();
				}
				beamBig2[ i ].move( time );
			}
		}

		if( con1 > 100 ){
			for( int i = 0; i < BEAMBIG1; i++ ){
				if( beamBig3[ i ].inStorage() ){
					break;
				}
				// big���㕔�܂ł�������
				if( con1 > 200 ){
					beamBig3[ i ].setFlag = 1;
				}
				if( beamBig3[ i ].setFlag == 0 ){
					beamBig3[ i ].setBigFall1( i );
				}else{
					beamBig3[ i ].goBigFall();
				}
				beamBig3[ i ].move( time );
			}
		}

		if( con1 > 150 ){
			for( int i = 0; i < BEAMBIG2; i++ ){
				if( beamBig4[ i ].inStorage() ){
					break;
				}
				// big���㕔�܂ł�������
				if( con1 > 250 ){
					beamBig4[ i ].setFlag = 1;
				}
				if( beamBig4[ i ].setFlag == 0 ){
					beamBig4[ i ].setBigFall2( i );
				}else{
					beamBig4[ i ].goBigFall();
				}
				beamBig4[ i ].move( time );
			}
		}


		if( con1 > 200 ){
			for( int i = 0; i < BEAMBIG1; i++ ){
				if( beamBig5[ i ].inStorage() ){
					con1 = 0;
					break;
				}
				// big���㕔�܂ł�������
				if( con1 > 300 ){
					beamBig5[ i ].setFlag = 1;
				}
				if( beamBig5[ i ].setFlag == 0 ){
					beamBig5[ i ].setBigFall1( i );
				}else{
					beamBig5[ i ].goBigFall();
				}
				beamBig5[ i ].move( time );
				if( beamBig5[ i ].inStorage() ){
					con1 = 0;
					beamBig5[ i ].setFlag = 0;
				}
			}
		}
	}

	public void initBigFall(){
		for( int i = 0; i < BEAMBIG1; i++ ){
			beamBig1[ i ].setFlag = 0;
			beamBig3[ i ].setFlag = 0;
			beamBig5[ i ].setFlag = 0;
		}
		for( int i = 0; i < BEAMBIG2; i++ ){
			beamBig2[ i ].setFlag = 0;
			beamBig4[ i ].setFlag = 0;
		}
	}



// �Փ˔��� �G�C���A���r�b�O�t�H�[�� -> �v���C���[
	public void collisionABp( PlayerSprite player ){
		if( Cons.DAMAGE_FLAG == 0 ){
 			for( int i = 0; i < BEAMBIG1; i++ ){
				// ���[�v������
				if( beamBig1[ i ].inStorage() ){
					continue;
				}
				if( beamBig1[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
 			for( int i = 0; i < BEAMBIG2; i++ ){
				// ���[�v������
				if( beamBig2[ i ].inStorage() ){
					continue;
				}
				if( beamBig2[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
 			for( int i = 0; i < BEAMBIG1; i++ ){
				// ���[�v������
				if( beamBig3[ i ].inStorage() ){
					continue;
				}
				if( beamBig3[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
 			for( int i = 0; i < BEAMBIG2; i++ ){
				// ���[�v������
				if( beamBig4[ i ].inStorage() ){
					continue;
				}
				if( beamBig4[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
 			for( int i = 0; i < BEAMBIG1; i++ ){
				// ���[�v������
				if( beamBig5[ i ].inStorage() ){
					continue;
				}
				if( beamBig5[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
		}
	}
////////////////////////// �G�C���A���K�[�h //////////////////////////////////////////
//�@�G�C���A���K�[�h��
	public void alienGuard( double tatalTime, BeamSprite[] beamPlayer, GraphicsContext gc ){
		beamAlienGuard( tatalTime );
		collisionAGpb( beamPlayer );
		collisionAGp( player );
		for( int i = 0; i < BEAMGUARD; i++ ){
			beamGurad[ i ].render( gc );
		}
	}
// �G�C���A���K�[�h�̑J��
	public void beamAlienGuard ( double time ){
		beamGurad[ 0 ].round1( time, alien );
		beamGurad[ 1 ].round2( time, alien );
		beamGurad[ 2 ].round3( time, alien );
		beamGurad[ 3 ].round4( time, alien );
	}
// �Փ˔��� �G�C���A���K�[�h -> �v���C���[�r�[��
	public void collisionAGpb( BeamSprite[] pbeam ){
		for( int i = 0; i < BEAMGUARD; i++ ){
			for( int j = 0; j < Cons.B_NUM; j++ ){
				if( beamGurad[ i ].intersects( pbeam[ j ] ) ){
					if( rand.nextInt( 2 ) == 0 ){
						pbeam[ j ].setVelocity( Cons.SPEED_B, Cons.SPEED_B);
					}else{
						pbeam[ j ].setVelocity( -Cons.SPEED_B, Cons.SPEED_B);
					}
				}
			}
		}
	}
// �Փ˔��� �G�C���A���K�[�h -> �v���C���[
	public void collisionAGp( PlayerSprite player ){
		if( Cons.DAMAGE_FLAG == 0 ){
 			for( int i = 0; i < BEAMGUARD; i++ ){
				// ���[�v������
				if( beamGurad[ i ].inStorage() ){
					continue;
				}
				if( beamGurad[ i ].intersects( player ) ){
					Cons.HP--;
					Cons.DAMAGE_FLAG = 1;
				}
			}
		}
	}
/////////////////////////////////////////////////////////////////////////
// �{�X���j
	public void deadAlien(){
		if( Cons.HP_BOSS <= 0 ){
			clearFlag = 1;
			stageCount = 0;
		}
	}
}
