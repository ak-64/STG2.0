package application;

public class AlienBossSprite extends AlienSprite{
	double positionCenterX;
	double positionCenterY;

	AlienBossSprite( ){
		super( 20, 300 );
		setImage( Cons.ALIEN_RED );
		setPosition( 270 - ( width / 2 ), 200 - ( height / 2 ) );
		setCenter();
	}

// ���S���擾
	public void setCenter(){
		positionCenterX = positionX + ( width / 2 );
		positionCenterY = positionY + ( height / 2 );
	}
// �_���[�W�v�Z
	public void damage(){
		Cons.HP_BOSS--;
		if( Cons.HP_BOSS < 0 ){
			Cons.HP_BOSS = 0;
		}
	}
// ���Ȃ�true
	public boolean inDead(){
		if( Cons.HP_BOSS <= 0 ){
			return true;
		}
		return false;
	}
}
