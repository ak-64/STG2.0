package application;

public class BeamBigSprite extends BeamSprite{
	double storageX = -100;
	double storageY = -100;
	int setFlag = 0;

// �R���X�g���N�^  �����ݒ�
	BeamBigSprite( Sprite sprite ){
		super();
		beamGo( sprite );
        setImage( Cons.BEAM_BIG_RED );
	}
// big ���@�{�X�̂Ƃ���ɂ����true
	public boolean inAlien( AlienSprite alien ){
		if( alien.positionX == positionX && alien.positionY == positionY ){
			return true;
		}
		return false;
	}
	
// big ����	
	public void setBigFall1( int i ){
		double capX;
		double capY;
		double max;
	
		capX = 80 * i - positionX;
		capY = 0 - positionY;
		max = Math.max( Math.abs( capX ), Math.abs( capY ) );
		capX = capX / max * 500;
		capY = capY / max * 500;
		setVelocity( capX, capY );
	}
// big ����	
	public void setBigFall2( int i ){
		double capX;
		double capY;
		double max;
	
		capX = 40 + ( 80 * i - positionX );
		capY = 0 - positionY;
		max = Math.max( Math.abs( capX ), Math.abs( capY ) );
		capX = capX / max * 500;
		capY = capY / max * 500;
		setVelocity( capX, capY );
	}

	public void goBigFall(){
		setVelocity( 0, 200 );
	}

// ���ˈʒu
	public void beamGo( Sprite sprite ){
		positionX = sprite.positionX - 20;
		positionY = sprite.positionY + sprite.height ;
	}

// ��ʊO�ŃX�g���[�W��
 	public void outFrameBeam(){
 		if( positionX > 1080 ){
 			storageGO();
 		}
 		if( positionX < -540 ){
 			storageGO();
 		}
 		if( positionY > 600 ){
 			storageGO();
 		}
 		if( positionY < -540 ){
 			storageGO();
 		}
 	}

// �X�g���[�W��
 	public void storageGO(){
 		setVelocity( 0, 0 );
 		setPosition( storageX, storageY );
 	}

// �e���ۊǏꏊ�ɂ���ΐ^
 	public boolean inStorage(){
 		if( ( positionX == storageX ) && ( positionY == storageY ) ){
 			return true;
 		}
 		return false;
 	}
}

